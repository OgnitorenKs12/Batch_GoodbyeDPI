#  Hazırlayan: Hüseyin UZUNYAYLA / OgnitorenKs
###  İletişim;
-   Discord: https://discord.gg/7hbzSGTYeZ
-   Mail: ognitorenks@gmail.com
-   Site: [https://ognitorenks.blospot.com](https://ognitorenks.blospot.com)


<details><B><summary> Versiyon 2.0 ► 07.05.2025 </B></summary>

    • --set-ttl 3 yönteminde birçok kullanıcı sorun yaşıyordu.
    • Çözüm olarak alternatif bir yöntem daha ekledim > --set-ttl 3 --dns-addr 77.88.8.8 --dns-port 1253 --dnsv6-addr 2a02:6b8::feed:0ff --dnsv6-port 1253
    
</details>